#!/bin/bash

VERSION=`cat /etc/os-release | grep VERSION_ID| awk -F "=\"" '{print $2}' | cut -d'.' -f1`
SYSTEM=`lsb_release -a 2>/dev/null|grep -c -E '(Debian)|(Ubuntu)' `

if [ -e /etc/redhat-release ] 
then 
  rpm -ivh RHEL/RHEL${VERSION}/*.rpm

elif [ $SYSTEM -gt 0 ] 
then
  dpkg -i UBUNTU/UBUNTU${VERSION}/*.deb

else
  rpm -ivh SLES/SLES${VERSION}/*.rpm

fi

if [ $? = 0 ]
then
   echo "$UTIL_NAME is installed successfully" 
else
   echo "$UTIL_NAME installation is failed" 
fi
