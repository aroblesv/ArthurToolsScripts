#!/bin/bash

# + ============================================================== +
# Copyright (c) 2023, Intel Corporation.

# This source code and any documentation accompanying it ("Material") is furnished
# under license and may only be used or copied in accordance with the terms of that
# license.  No license, express or implied, by estoppel or otherwise, to any
# intellectual property rights is granted to you by disclosure or delivery of these
# Materials.  The Materials are subject to change without notice and should not be
# construed as a commitment by Intel Corporation to market, license, sell or support
# any product or technology.  Unless otherwise provided for in the license under which
# this Material is provided, the Material is provided AS IS, with no warranties of
# any kind, express or implied, including without limitation the implied warranties
# of fitness, merchantability, or non-infringement.  Except as expressly permitted by
# the license for the Material, neither Intel Corporation nor its suppliers assumes
# any responsibility for any errors or inaccuracies that may appear herein.  Except
# as expressly permitted by the license for the Material, no part of the Material
# may be reproduced, stored in a retrieval system, transmitted in any form, or
# distributed by any means without the express written consent of Intel Corporation.

# Module Name:  startup.sh

# Abstract:  Shell Script file for invoking system software updates for
# Intel(R) Server Board S2600WFR Family.

CURRENT_PATH=$(pwd)
BASE_PATH="OFU/Linux_x64"
DIMM="fw_ekvb0_1.2.0.5446_rel.bin"
RESTART_FLAG="false"

uninstall()
{
    package=`rpm -qa | grep flashupdt`
    if [[ $package != "" ]]; then
	{
		echo "uninstalling flashupdt ..."
		rpm -e flashupdt
	}
	fi
}

install()
{
    uninstall
	echo "Installing flashupdt ..."
	cd $BASE_PATH
	sh install.sh
	cd $CURRENT_PATH
}

refresh_terminal()
{
	echo "Refreshing environment ..."
	source ~/.bashrc
}

update_stacks()
{
	ofu_dir="/usr/bin/flashupdt"
    if [ -d "$ofu_dir" ]; then
        echo "Flashupdt found to be installed. Updates will start now..."
        cd $ofu_dir
        flashupdt -u $CURRENT_PATH/flashupdt.cfg
        echo "Update completed for BIOS, BMC, ME, FRUSDR. Updates for Apache Pass DIMM firmware will start now..."
		RESTART_FLAG="true"
	else
        echo "Flashupdt utility is missing. Kindly install it."
        exit 1
    fi
}

update_dimms()
{

	echo "dir path is $CURRENT_PATH"
	echo " $DIMM"
	which ipmctl 2>/tmp/null
	status_aps=$?
	if [ $status_aps -eq 0 ]; then
	
		ipmctl_ver=`ipmctl version`
		if [[ "$ipmctl_ver" == *"01.00"* ]]; then
			arg="-f -dimm"
		else
			arg="-lpmb -dimm"
		fi
		
		echo "Apache Pass Driver found to be installed. Apache Pass DIMM firmware update will continue."
		ID=$(ipmctl show -d SubsystemRevisionID -dimm | grep "SubsystemRevisionID" | head -1)
		SubsystemRevisionID="$(echo "$ID" | sed "s/ //g")"
		if [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0000 ]; then
			echo "EKV Controller Rev Code is A0. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0010 ]; then
			echo "EKV Controller Rev Code is S0. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0011 ]; then
			echo "EKV Controller Rev Code is S1. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0012 ]; then
			echo "EKV Controller Rev Code is S1b rev 46. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0013 ]; then
			echo "EKV Controller Rev Code is S1 rev89. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0014 ]; then
			echo "EKV Controller Rev Code is S1b IOPSS Bin2. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0015 ]; then
			echo "EKV Controller Rev Code is S1b IOPSS Bin1. No binary available to update the firmware."
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0016 ]; then
			echo "EKV Controller Rev Code is B0: PO, VIS."
			ipmctl load -source $CURRENT_PATH/$DIMM $arg
			RESTART_FLAG="true"
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0017 ]; then
			echo "EKV Controller Rev Code is B0:preQS."
			ipmctl load -source $CURRENT_PATH/$DIMM $arg
			RESTART_FLAG="true"
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0018 ]; then
			echo "EKV Controller Rev Code is B0: QS."
			ipmctl load -source $CURRENT_PATH/$DIMM $arg
			RESTART_FLAG="true"
		elif [ "$SubsystemRevisionID" == SubsystemRevisionID=0x0019 ]; then
			echo "EKV Controller Rev Code is B0: HVM."
			ipmctl load -source $CURRENT_PATH/$DIMM $arg
			RESTART_FLAG="true"
		else
			echo "EKV Controller Rev Code is unknown or DIMM not installed."
		fi
	else
		echo "Apache Pass driver missing. Kindly install the driver to update the Apache Pass firmware."
		exit 1
	fi
}

restart()
{
	echo -e "\n\n"
	if [[ $RESTART_FLAG == "true" ]]; then
	        echo "Resetting system, will take approximately 10 minutes"
			shutdown -r +1
	fi
}

echo -e "\n\n"
echo "===================================================== Update Menu ====================================================="
echo 1. Update BIOS, BMC, ME, FRUSDR, DCPMM DIMMs
echo 2. Update BIOS, BMC, ME, FRUSDR only.
echo 3. Update DCPMM DIMMs only
echo 4. Exit.
echo "===================================================== Update Menu ====================================================="
echo -e "\n"
echo "Enter [1/2/3/4] from the above update menu and pres Enter:" 
read option

if [ "$option" == "1" ]
then
	echo "Starting updates for BIOS, BMC, ME, FRUSDR and DCPMM DIMM firmware."
	install
	refresh_terminal
	update_stacks
	update_dimms
	restart
elif [ "$option" == "2" ]
then
    echo "Starting updates for BIOS, BMC, ME and FRUSDR only."
	install
	refresh_terminal
	update_stacks
	restart
elif [ "$option" == "3" ]
then
    echo "Starting updates for DCPMM firmware only."
	update_dimms
	restart
elif [ "$option" == "4" ]
then
    echo "Exiting without performing any updates."
	exit
else
    echo "Invalid input."
    exit 1
fi

